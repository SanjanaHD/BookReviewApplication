export class ReviewRequest {
  userId: string;
  bookId: string;
}
