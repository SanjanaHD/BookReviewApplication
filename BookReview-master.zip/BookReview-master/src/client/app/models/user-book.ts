export class UserBook {
  _id: string;
  userId: string;
  bookId: string;
  rating: number;
  review: string;
}
