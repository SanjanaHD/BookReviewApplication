export class Book {
  _id: string;
  title: string;
  authors: string;
  genre: string;
  image: string|any;
  //imagePath: string;
  desc: string;
}
