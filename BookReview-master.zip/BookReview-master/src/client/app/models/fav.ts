export class Fav {
  _id: string;
  userId: string;
  bookId: string;
}
